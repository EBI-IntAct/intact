package mypackage;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.ServletException;
import java.io.PrintWriter;
import java.io.IOException;

/**
 * This is the HelloWorld servlet
 * Author: Samuel Kerrien (skerrien@ebi.ac.uk)
 */

public class HelloWorld extends HttpServlet {
    public void doGet(HttpServletRequest request, HttpServletResponse response)
            throws IOException, ServletException {

       response.setContentType("text/html");
       PrintWriter out = response.getWriter();

       out.println ("<HTML><HEAD><TITLE>Hello World</TITLE></HEAD>\n" +
                    "<BODY><H1>Hello World</H1></BODY></HTML>");
   }
}





