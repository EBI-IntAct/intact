package mypackage;

import com.sun.image.codec.jpeg.JPEGImageEncoder;
import com.sun.image.codec.jpeg.JPEGCodec;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.ServletException;

import java.io.IOException;
import java.io.OutputStream;
import java.io.BufferedOutputStream;

import java.util.Random;
import java.awt.*;
import java.awt.image.BufferedImage;

/**
 * This is the Image Generation servlet
 * Author: Samuel Kerrien (skerrien@ebi.ac.uk)
 */

public class DynamicImage extends HttpServlet {

    public void service (HttpServletRequest request, HttpServletResponse response)
            throws IOException, ServletException {

        // Create image
        int width=200, height=200;
        BufferedImage image = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);

        // Get drawing context
        Graphics g = image.getGraphics();

        // Fill background
        g.setColor(Color.white);
        g.fillRect(0, 0, width, height);

        // Create random polygon
        Polygon poly = new Polygon();
        Random random = new Random();
        for (int i=0; i < 5; i++) {
            poly.addPoint (random.nextInt(width),
                           random.nextInt(height));
        }

        // Fill polygon
        g.setColor(Color.red);
        g.fillPolygon(poly);

        // Dispose context
        g.dispose();

        // Send image to browser
        response.setContentType("image/jpg");
        OutputStream outputStream = new BufferedOutputStream(response.getOutputStream(), 1024);
        JPEGImageEncoder encoder = JPEGCodec.createJPEGEncoder(outputStream);
        encoder.encode(image);
        outputStream.close();
    }
}





