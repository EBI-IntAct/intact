//-*-c++-*-
#ifndef _TEMPLATEFACTORY_H
#define _TEMPLATEFACTORY_H
#include <map>
#include <string>
#include <dlfcn.h>
#include <dirent.h>
#include "PluginLoader.h"

template<class ObjectFactory, class ObjectType, class Parameter> class TemplateFactory
{
public:
  typedef void *(*func)();
  typedef std::map< std::string , ObjectFactory * , std::less<std::string> > ObjectCreator;
  void *handle;
  func createObj;
  ObjectCreator objMap;
  map<std::string,StructDef> objParam;
  void load(std::string pluginPath,std::string type,PluginLoader *loader=0);
  ObjectType *getObject(std::string name,Parameter p);
  StructDef getParam(std::string name);
};

#include "./cxx/TemplateFactory.cxx"
#endif































