#ifndef TLP_PROGRESS
#define TLP_PROGRESS
#include <string>
class PluginProgress {
 public:
  //return 0 to continue, 1 to cancel, 2 to stop.
  virtual bool progress(int step, int max_step)=0;
};

class PluginProgressDefault: public PluginProgress {
 public:
  bool progress(int step, int max_step);
};
#endif
