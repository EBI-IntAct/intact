//-*-c++-*-
#ifndef _COLOR_H
#define _COLOR_H
///
class Color
{
 private:
  unsigned char R,G,B,A;

 public:
  ///
  Color(const unsigned char=0 ,const unsigned char=0 ,const unsigned char=0,const unsigned char=0);
  ///
  void set(const unsigned char=0,const unsigned char=0 ,const unsigned char=0, const unsigned char=0);
  ///
  float getRGL()const;
  ///
  float getGGL()const;
  ///
  float getBGL()const;
  ///
  float getAGL()const;
  ///
  float* getGL()const;
  ///
  unsigned char getR()const;
  ///
  unsigned char getG()const;
  ///
  unsigned char getB()const;
  ///
  unsigned char getA()const;
  ///
  void setR(const unsigned char );
  ///
  void setG(const unsigned char );
  ///
  void setB(const unsigned char );
  ///
  void setA(const unsigned char );
  ///
  long getTrueColor();
  ///
  bool operator==(const Color &) const;
  ///
  bool operator!=(const Color &) const;
};
#endif

