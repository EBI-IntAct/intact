//-*-c++-*-
#ifndef _CLUSTERING_H
#define _CLUSTERING_H

#include <list>
#include <string>
#include "SuperGraph.h"
#include "MethodFactory.h"
#include "WithParameter.h"
///Interface for clustering plug-ins
class Clustering : public WithParameter
{ 
public :
  ///
  SuperGraph *superGraph;
  ///
  Clustering (ClusterContext context):superGraph(context.superGraph){}
  ///
  virtual ~Clustering() {}
  ///
  virtual bool run() = 0;
  ///
  virtual bool check(std::string &) = 0;
  ///
  virtual void reset() = 0;  
};

#endif






