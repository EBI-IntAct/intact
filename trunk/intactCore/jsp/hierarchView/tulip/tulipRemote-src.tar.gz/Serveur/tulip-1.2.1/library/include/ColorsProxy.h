//-*-c++-*-
#ifndef Tulip_ColorsProxy_H
#define Tulip_ColorsProxy_H

#include <string>
#include "Types.h"
#include "PropertyProxy.h"
#include "Colors.h"
#include "MethodFactory.h"
#include "TemplateFactory.h"


class PropertyContext;

///
class ColorsProxy:public PropertyProxy<ColorType,ColorType>
{ 
  ///
  friend class Colors;

public:
  static TemplateFactory<ColorsFactory,Colors,PropertyContext *> factory;

private:
  ///
  Colors *currentColors;

public :
  ///
  ColorsProxy (PropertyContext *context);
  ///
  ~ColorsProxy();
  ///
  bool select(std::string , std::string &);
  ///
  void reset_handler();
  ///
  void recompute_handler();

};

#endif

