#ifndef _TULIPREFLECT
#define _TULIPREFLECT
#include <iostream>
#include <string>
#include <map>
#include <cassert>
#include <typeinfo>
#include "Iterator.h"

struct DataType {
  DataType(){}
  DataType(void *value,const type_info &typeName):value(value),typeName(typeName.name()){}
  void * value;
  string typeName;
};

//This class enables to define a structure
struct StructDef {
  //Add the variable of type T and name str in the structure.
  template<typename T> void add(string str);
  //Get iterator on structure fields
  Iterator< pair<string,string> >* getField();
  //Remove the variable which have str has name in the structure.
  void erase(string str);
private:
  map<string,string> data;
};

/**  A container which allows insertion of different type.
     The inserted data must have a copy-constructor well done */
struct DataSet {
  /**Return a copy of the value of the variable with name str.
     Type are checked in Debug Mode.
     If the variable str doesn't exist return false else true. */
  template<typename T> bool get(const string &str,T& value);
  /**Return a copy of the value of the variable with name str.
     Type are checked in Debug Mode.
     If the variable str doesn't exist return false else true.
     The data is removed after the call. */
  template<typename T> bool getAndFree(const string &str,T& value);
  /** Set the value of the variable str.*/
  template<typename T> void set(const string &str,const T& value);
  /**return true if str exists else false.*/
  bool exist(const string &str);
private:
  map<string,DataType> data;
};

#include "cxx/Reflect.cxx"

#endif
