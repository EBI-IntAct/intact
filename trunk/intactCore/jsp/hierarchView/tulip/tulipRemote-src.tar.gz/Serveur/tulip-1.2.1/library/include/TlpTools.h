//-*-c++-*-
#ifndef _TLPTOOLS_H
#define _TLPTOOLS_H
#include <string>
#include <iostream>
#include "MethodFactory.h"
#include "SuperGraph.h"
#include "LayoutProxy.h"
#include "MetricProxy.h"
#include "StringProxy.h"
#include "SelectionProxy.h"
#include "ColorsProxy.h"
#include "IntProxy.h"
#include "SizesProxy.h"
#include "PluginProgress.h"

namespace TlpTools {
  extern TemplateFactory<ClusteringFactory,Clustering,ClusterContext > clusteringFactory;
  extern TemplateFactory<ImportModuleFactory,ImportModule,ClusterContext > importFactory;
  extern TemplateFactory<ExportModuleFactory,ExportModule,ClusterContext > exportFactory;
  void loadPlugins(PluginLoader *plug=0);

  SuperGraph * importGraph(const std::string &filename,const std::string &alg="tlp" , PluginProgress *plugProgress=0);
  bool exportGraph(SuperGraph *sg,std::ostream  &os,const std::string &alg="tlp" , PluginProgress *plugProgress=0);
  bool clusterizeGraph(SuperGraph *sg,std::string &errorMsg, const std::string &alg="hierarchical" , PluginProgress *plugProgress=0);
  SuperGraph* newSuperGraph();
  //  return an empty sub graph 
  SuperGraph *newSubGraph(SuperGraph *);
};

#endif
