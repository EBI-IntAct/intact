//-*-c++-*-
#ifndef Tulip_COORD_H
#define Tulip_COORD_H
///
class Coord
{
  friend Coord operator +(const Coord &c1,const Coord &c2);
  friend Coord operator -(const Coord &c1,const Coord &c2);
  friend Coord operator ^(const Coord &c1,const Coord &c2);
  friend Coord operator /(const Coord &c1,const double scalaire);
  friend Coord operator *(const Coord &c1,const double scalaire);
  friend double operator*(const Coord &c1,const Coord &c2);

private:
  double v[3];
public:
  Coord(const double=0,const double=0,const double=0);
  ///
  void set(const double=0,const double=0,const double=0);
  ///
  void set(const Coord&);
  ///
  void setX(double);
  ///
  void setY(double);
  ///
  void setZ(double);
  ///
  double getX() const;
  ///
  double getY() const;
  ///
  double getZ() const;
  ///
  double norm() const;
  ///
  double dist(const Coord&) const;
  ///
  Coord & operator *=(const Coord&);
  ///
  Coord & operator *=(const double);
  ///
  Coord & operator /=(const Coord&);
  ///
  Coord & operator /=(const double);
  ///
  Coord & operator -=(const Coord&);
  ///
  Coord & operator -=(const double);
  ///
  Coord & operator +=(const Coord&);
  ///
  Coord & operator +=(const double);
  ///
  void get(double &, double &, double &) const;
  ///
  bool operator ==(const Coord &) const;
  bool operator !=(const Coord &) const;
};

Coord operator +(const Coord &c1,const Coord &c2);
Coord operator -(const Coord &c1,const Coord &c2);
Coord operator ^(const Coord &c1,const Coord &c2);
Coord operator /(const Coord &coord,const double scalaire);
Coord operator *(const Coord &coord,const double scalaire);
double operator *(const Coord &c1,const Coord &c2);
#endif
