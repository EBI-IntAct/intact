//-*-c++-*-
#ifndef Tulip_LAYOUTPROXY_H
#define Tulip_LAYOUTPROXY_H

#include <string>
#include "Types.h"
#include "PropertyProxy.h"
#include "Layout.h"
#include "MethodFactory.h"
#include "TemplateFactory.h"

class PropertyContext;


///
class LayoutProxy:public PropertyProxy<PointType,LineType>
{
  ///
  friend class Layout;

public:
  ///
  static TemplateFactory<LayoutFactory,Layout,PropertyContext *> factory;

private:
  ///
  Coord max,min;
  ///
  bool minMaxOk;
  ///
  void computeMinMax();
  ///
  Layout *currentLayout;

public:
  ///
  LayoutProxy (PropertyContext *context);
  ///
  LayoutProxy ();
  ///
  ~LayoutProxy();
  ///
  bool select(std::string , std::string &);
  ///
  bool computeOtherLayout(std::string , std::string &);

  //=======================================
  //Functions for extra layout information
  Coord getMax();
  Coord getMin();
  ///
  double  getMaxX();
  ///
  double  getMinX();
  ///
  double  getMaxY();
  ///
  double  getMinY();
  ///
  double  getMaxZ();
  ///
  double  getMinZ();

  //============================================
  //Functions for layout modification
  ///
  void center();
  ///
  void normalize();
  ///
  void reset_handler();
  ///
  void recompute_handler();
  ///
  void resetBoundingBox();
  ///
  void clone_handler(PropertyProxy<PointType,LineType> &);
};

#endif










