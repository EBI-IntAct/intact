#ifndef _TULIPWITHPARAMETER
#define _TULIPWITHPARAMETER
#include "Reflect.h"
struct WithParameter {
  ///
  StructDef getParameters();
  ///
  template<typename Ty> void addParameter(string str){parameters.template add<Ty>(str);}
protected:
  ///
  StructDef parameters;
};

#endif
