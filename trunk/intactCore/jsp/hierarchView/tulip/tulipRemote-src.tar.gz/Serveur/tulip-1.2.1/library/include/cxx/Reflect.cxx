#include "StlIterator.h"

//=======================================================================
//Strucdef implementation
template<typename T> void StructDef::add(string str){
  if (data.find(str)==data.end()) {
    data[str]=typeid(T).name();
  }
#ifndef NDEBUG
  else {
    cerr << "StructDef::addVar " << str << " already exists" << endl;
  }
#endif
}
//=======================================================================
//DataSet implementation
template<typename T> bool DataSet::get(const string &str,T& value) {
  if (data.find(str)!=data.end()) {
    assert(data[str].typeName==typeid(T).name());
    value=*((T*)(data[str].value));
    return true;
  }
  else
    return false;
}
template<typename T> bool DataSet::getAndFree(const string &str,T& value) {
  if (get(str,value)) {
    delete ((T*)(data[str].value));
    data.remove(str);
    return true;
  }
  else
    return false;
}
template<typename T> void DataSet::set(const string &str,const T& value) {
  if (data.find(str)!=data.end()) {
    assert(data[str].typeName==typeid(T).name());
    delete (T*)(data[str].value);
  }
  T* tmp=new T(value);
  data[str]=DataType((void *)tmp,typeid(T));
}

//=======================================================================
