//-*-c++-*-
#ifndef Tulip_SelectionProxy_H
#define Tulip_SelectionProxy_H

#include <string>
#include "Types.h"
#include "PropertyProxy.h"
#include "Selection.h"
#include "MethodFactory.h"
#include "TemplateFactory.h"

class PropertyContext;


///
class SelectionProxy:public PropertyProxy<BooleanType,BooleanType>
{ 
  ///
  friend class Selection;

public:
  static TemplateFactory<SelectionFactory,Selection,PropertyContext *> factory;

private:
  Selection *currentSelection;

public :
  ///
  SelectionProxy (PropertyContext *context);
  ///
  ~SelectionProxy();
  ///
  bool reCompute(std::string &erreurMsg);
  ///
  bool select(std::string , std::string &);
  ///
  void reset_handler();
  ///
  void recompute_handler();  
  ///Effectue un not sur tous les �l�ment visible du proxy
  void reverse();
  ///hide all the element of the visible graph which are true in this Selection Proxy
  ///Also deprecated ou bien � ne mettre que dans le module de vue.
  void hideSelection();
  ///reverse all the direction of edges of the visible graph which are true in this Selection Proxy
  void reverseEdgeDirection();
};



#endif








