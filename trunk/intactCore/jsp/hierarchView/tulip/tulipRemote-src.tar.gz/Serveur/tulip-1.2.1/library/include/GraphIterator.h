//-*-c++-*-
/**
 Author: David Auber
 Email : auber@labri.fr
 Last modification : 20/08/2001
 This program is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by  
 the Free Software Foundation; either version 2 of the License, or     
 (at your option) any later version.
*/
#ifndef Tulip_GGRAPHITERATOR_H
#define Tulip_GGRAPHITERATOR_H
#include "Iterator.h"
#include "SuperGraph.h"
#include "SuperGraphImpl.h"

typedef std::hash_map<edge,std::pair< node , node > > edgesStruct;
typedef std::hash_map<node,std::pair< std::vector<edge> , std::vector<edge> > > nodesStruct;

class SelectionProxy;
class SubGraph;
template<class C>class Iterator;

//===========================================================
///Factorization of code for iterators
template<class itType> class FactorIterator:public Iterator<itType>
{
 protected:
  SuperGraph *_parentGraph;
  SelectionProxy *_selectionProxy;
 public:
  FactorIterator(const SuperGraph *sG,const SubGraph *subG):
    _parentGraph(sG->getFather()),
    _selectionProxy(subG->getSubGraphProxy())
  {}
};
//============================================================
///Node iterator for SuperGraphView
class SGraphNodeIterator:public FactorIterator<node>
{
 private:
  Iterator<node> *it;
  node curNode;
  bool _hasnext;

 public:
  SGraphNodeIterator(const SuperGraph *sG,const SubGraph *subG);
  ~SGraphNodeIterator();
  node next();
  bool hasNext();
};
//============================================================
///Out node iterator for SuperGraphView
class OutNodesIterator:public FactorIterator<node>
{
 private:
  Iterator<edge> *it;
 public:
  OutNodesIterator(const SuperGraph *sG,const SubGraph *subG,node n);
  ~OutNodesIterator();
  node next();
  bool hasNext();
};
//============================================================
///In node iterator for SuperGraphView
class InNodesIterator:public FactorIterator<node>
{
 private:
  Iterator<edge> *it;
 public:
  InNodesIterator(const SuperGraph *sG,const SubGraph *subG,node n);
  ~InNodesIterator();
  node next();
  bool hasNext();
};
//============================================================
///In Out node iterator for SuperGraphView
class InOutNodesIterator:public FactorIterator<node>
{
 private:
  Iterator<node> *it1,*it2;

 public:
  InOutNodesIterator(const SuperGraph *sG,const SubGraph *subG,node n);
  ~InOutNodesIterator();
  node next();
  bool hasNext();
};
//=============================================================
///Edge iterator for SuperGraphView
class SGraphEdgeIterator:public FactorIterator<edge>
{
 private:
  Iterator<edge> *it;
  edge curEdge;
  bool _hasnext;

 public:
  SGraphEdgeIterator(const SuperGraph *sG,const SubGraph *subG);
  ~SGraphEdgeIterator();
  edge next();
  bool hasNext();
};
//============================================================
///Out edge iterator for SuperGraphView
class OutEdgesIterator:public FactorIterator<edge>
{
 private:
  Iterator<edge> *it;
  edge curEdge;
  bool _hasnext;

 public:
  OutEdgesIterator(const SuperGraph *sG,const SubGraph *subG,node n);
  ~OutEdgesIterator();
  edge next();
  bool hasNext();
};
//============================================================
///In edge iterator for SuperGraphViwe
class InEdgesIterator:public FactorIterator<edge>
{
 private:
  Iterator<edge> *it;
  edge curEdge;
  bool _hasnext;

 public:
  InEdgesIterator(const SuperGraph *sG,const SubGraph *subG,node n);
  ~InEdgesIterator();
  edge next();
  bool hasNext();
};
//============================================================
///In Out edge iterator for SuperGraphView
class InOutEdgesIterator:public FactorIterator<edge>
{
 private:
  Iterator<edge> *it;
  edge curEdge;
  bool _hasnext;

 public:
  InOutEdgesIterator(const SuperGraph *sG,const SubGraph *subG,node n);
  ~InOutEdgesIterator();
  edge next();
  bool hasNext();
};
//============================================================
//Iterator for the SuperGraphImpl
//============================================================
///Node iterator for data graph
class xSGraphNodeIterator:public FactorIterator<node>
{
 private:
  nodesStruct::iterator it;
  nodesStruct::iterator itEnd;
 public:
  xSGraphNodeIterator(const SuperGraph *sG,const SubGraph *subG);
  ~xSGraphNodeIterator();
  node next();
  bool hasNext();
};
//============================================================
///Out Node iterator for data graph
class xOutNodesIterator:public FactorIterator<node>
{
 private:
  Iterator<edge> *it;
 public:
  xOutNodesIterator(const SuperGraph *sG,const SubGraph *subG,node n);
  ~xOutNodesIterator();
  node next();
  bool hasNext();
};
//============================================================
///In Node iterator for data graph
class xInNodesIterator:public FactorIterator<node>
{
 private:
  Iterator<edge> *it;
 public:
  xInNodesIterator(const SuperGraph *sG,const SubGraph *subG,node n);
  ~xInNodesIterator();
  node next();
  bool hasNext();
};
//============================================================
///In Out Node iterator for data graph
class xInOutNodesIterator:public FactorIterator<node>
{
  Iterator<node> *it1,*it2;
 public:
  xInOutNodesIterator(const SuperGraph *sG,const SubGraph *subG,node n);
  ~xInOutNodesIterator();
  node next();
  bool hasNext();
};
//=============================================================
///Edge iterator for data graph
class xSGraphEdgeIterator:public FactorIterator<edge>
{
 private:
  edgesStruct::iterator it;
  edgesStruct::iterator itEnd;
 public:
  xSGraphEdgeIterator(const SuperGraph *sG,const SubGraph *subG);
  ~xSGraphEdgeIterator();
  edge next();
  bool hasNext();
};
//============================================================
///Out edge iterator for data graph
class xOutEdgesIterator:public FactorIterator<edge>
{
 private:
  std::vector<edge>::iterator it,itEnd;
 public:
  xOutEdgesIterator(const SuperGraph *sG,const SubGraph *subG,node n);
  ~xOutEdgesIterator();
  edge next();
  bool hasNext();
};
//============================================================
///In edge iterator for data graph
class xInEdgesIterator:public FactorIterator<edge>
{
  std::vector<edge>::iterator it,itEnd;
 public:
  xInEdgesIterator(const SuperGraph *sG,const SubGraph *subG,node n);
  ~xInEdgesIterator();
  edge next();
  bool hasNext();
};
//============================================================
///In out edge iterator for data graph
class xInOutEdgesIterator:public FactorIterator<edge>
{
  Iterator<edge> *itIn,*itOut;
public:
  xInOutEdgesIterator(const SuperGraph *sG,const SubGraph *subG,node n);
  ~xInOutEdgesIterator();
  edge next();
  bool hasNext();
};
//=============================================================
#endif








