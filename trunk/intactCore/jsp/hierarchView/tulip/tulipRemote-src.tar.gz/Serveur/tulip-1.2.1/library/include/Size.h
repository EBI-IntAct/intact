//-*-c++-*-
#ifndef Tulip_SIZE_H
#define Tulip_SIZE_H
///
class Size
{
private:
  double h,w,d;
public:
  Size(const double=0,const double=0,const double=0);
  ///
  void set(const double=0,const double=0,const double=0);
  ///
  void set(const Size&);
  ///
  void setH(const double);
  ///
  void setW(const double);
  ///
  void setD(const double);
  ///
  double getH() const;
  ///
  double getW() const;
  ///
  double getD() const;
  ///
  double norm() const;
  ///
  void get(double &, double &, double &) const;
  ///
  bool operator ==(const Size &) const;
  ///
  bool operator !=(const Size &) const;
};

#endif
