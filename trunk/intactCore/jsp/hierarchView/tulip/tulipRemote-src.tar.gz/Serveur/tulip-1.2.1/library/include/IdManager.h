//-*-c++-*-
/**
 Author: David Auber
 Email : auber@labri.fr
 Last modification : 20/08/2001
 This program is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by  
 the Free Software Foundation; either version 2 of the License, or     
 (at your option) any later version.
*/

#ifndef _TulipIdManager_H
#define _TulipIdManager_H
#include <set>
#include <iostream>

class IdManager
{
  friend std::ostream& operator<<(std::ostream &,const IdManager &);

private:
  std::set<unsigned int> freeIds;  
  unsigned int maxId;
  unsigned int minId;

public:
  IdManager():maxId(0),minId(1){}
  bool is_free(unsigned int);
  /**
     Free the id given in parameter. This id
     will be accessible by a the get function.
  */
  void IdManager::free(const unsigned int);
  /**
     Return a new id, the returned id is choosen to minimize
     the memory space of the free list, and the fragmetation
     of the ids.
  */
  unsigned int get();
};

std::ostream& operator<<(std::ostream &,const IdManager &);

#endif
