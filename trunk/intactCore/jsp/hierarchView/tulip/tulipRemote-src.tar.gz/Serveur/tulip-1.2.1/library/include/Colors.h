//-*-c++-*-
/**
 Author: David Auber
 Email : auber@labri.fr
 Last modification : 20/08/2001
 This program is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by  
 the Free Software Foundation; either version 2 of the License, or     
 (at your option) any later version.
*/

#ifndef Tulip_COLORS_H
#define Tulip_COLORS_H

#include "Types.h"
#include "Property.h"
class PropertyContext;
class ColorsProxy;


/// Interface for colors plug-ins
class Colors:public Property< ColorType , ColorType >
{ 
  ///
  friend class ColorsProxy;
public:
  ColorsProxy *colorsProxy;
protected:
  ///
  Colors (PropertyContext  *context);
  ///
  virtual ~Colors(){}
};

#endif









