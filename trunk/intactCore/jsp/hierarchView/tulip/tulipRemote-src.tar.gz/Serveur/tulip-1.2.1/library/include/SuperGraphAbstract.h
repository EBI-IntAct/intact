//-*-c++-*-
#ifndef Tulip_SUPERGRAPHABSTRACT_H
#define Tulip_SUPERGRAPHABSTRACT_H

#include "SuperGraph.h"

class SelectionProxy;

///Abstract class for default graph operations.
class SuperGraphAbstract:public SuperGraph
{
public:
  SuperGraphAbstract();
  ~SuperGraphAbstract();
  //=======================================
  ///
  virtual int deg(node n) const;
  ///
  virtual int indeg(node n) const;
  ///
  virtual int outdeg(node n) const;
  ///
  virtual node source(const edge) const;
  ///
  virtual node target(const edge) const;
  ///
  virtual void reverse(const edge);
  //=======================================
  ///
  virtual bool isTree();
  ///
  virtual bool isAcyclic();
  ///
  virtual int numberOfNodes() const;
  ///
  virtual int numberOfEdges() const;
private:
  bool acyclicTest(node n,SelectionProxy *,SelectionProxy *);
};

#endif
