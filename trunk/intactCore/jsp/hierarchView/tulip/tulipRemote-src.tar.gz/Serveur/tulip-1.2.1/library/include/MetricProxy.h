//-*-c++-*-
#ifndef Tulip_MetricProxy_H
#define Tulip_MetricProxy_H

#include <string>
#include "Types.h"
#include "PropertyProxy.h"
#include "Metric.h"
#include "MethodFactory.h"
#include "TemplateFactory.h"

class PropertyContext;

///
class MetricProxy:public PropertyProxy<DoubleType,DoubleType>
{ 
  ///
  friend class Metric;

public:
  static TemplateFactory<MetricFactory,Metric,PropertyContext *> factory;

private:
  ///
  double maxN,minN,maxE,minE;
  ///
  bool minMaxOkNode;
  bool minMaxOkEdge;
  ///
  void computeMinMaxNode();
  void computeMinMaxEdge();
  ///
  Metric *currentMetric;

public :
  ///
  MetricProxy (PropertyContext *context);
  ///
  ~MetricProxy();
  ///
  bool select(std::string , std::string &);
  ///
  DoubleType::RealType  getNodeMin();
  ///
  DoubleType::RealType  getNodeMax();
  ///
  DoubleType::RealType  getEdgeMin();
  ///
  DoubleType::RealType  getEdgeMax();
  ///
  void reset_handler();
  ///
  void recompute_handler();
  ///
  void clone_handler(PropertyProxy<DoubleType,DoubleType> &);
};

#endif

