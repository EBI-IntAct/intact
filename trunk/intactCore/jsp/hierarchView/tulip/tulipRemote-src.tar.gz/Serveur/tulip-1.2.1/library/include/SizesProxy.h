//-*-c++-*-
#ifndef Tulip_SizesProxy_H
#define Tulip_SizesProxy_H

#include <string>
#include "Types.h"
#include "PropertyProxy.h"
#include "Sizes.h"
#include "MethodFactory.h"
#include "TemplateFactory.h"

class PropertyContext;

///
class SizesProxy:public PropertyProxy<SizeType,SizeType>
{ 
  ///
  friend class Sizes;

public:
  static TemplateFactory<SizesFactory,Sizes,PropertyContext *> factory;

private:
  ///
  Sizes *currentSizes;

public :
  ///
  SizesProxy (PropertyContext *context);
  ///
  ~SizesProxy();
  ///
  bool select(std::string , std::string &);
  ///
  void reset_handler();
  ///
  void recompute_handler();
};

#endif

