#ifndef __TULIPPLUGININCLUDE_H
#define __TULIPPLUGININCLUDE_H

#include "MethodFactory.h"
#include "Metric.h"
#include "MetricProxy.h"
#include "Layout.h"
#include "LayoutProxy.h"
#include "Selection.h"
#include "SelectionProxy.h"
#include "String.h"
#include "StringProxy.h"
#include "Clustering.h"
#include "ImportModule.h"
#include "Sizes.h"
#include "SizesProxy.h"
#include "Color.h"
#include "ColorsProxy.h"
#include "Int.h"
#include "IntProxy.h"
#include "SuperGraph.h"
#include "PropertyProxy.h"

#endif
