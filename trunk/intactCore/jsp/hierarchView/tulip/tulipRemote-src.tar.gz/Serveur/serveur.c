#include <stdio.h>
#include <signal.h>

#include <sys/types.h>
#include <sys/wait.h>
#include <sys/time.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <fcntl.h>

#define		VRAI	1
#define		FAUX	0
#define		DECONNECTE	2
#define		OK		1
#define		KO		0


#define 	MMax(x,y) (x>y ? x:y)
typedef void (*sighandler_t)(int);
int ftmp;
struct sockaddr_in caller;	

Kill()
{
	printf("Signal Kill\n");
	signal(SIGINT, (sighandler_t)Kill);
	exit(0);
}

Rupture()
{
      printf("Fin Connexion de: caller=%s,%d recoit %s\n"
		, inet_ntoa(caller.sin_addr)
		, ntohs(caller.sin_port)
		);
	signal(SIGPIPE, (sighandler_t)Rupture);
}


int
traiterRequete(int desc)
{
  char buf[100000];
  int read_ret, i;
  FILE * fichier;
  char nom_in[20],nom_out[20],commande[60];
  /* Une requ�te en attente sur le descripteur desc */

      sprintf(nom_in,"ser-tlp%d.tlp",ftmp);
      sprintf(nom_out,"ser-tlp%d.tlp",ftmp+1);

      sprintf(buf,"PASOK");
      commande[strlen(commande)] = '\n';
      fichier = fopen(nom_in,"wb+");
      printf("Requete numero %d\n",ftmp);

      while (strcmp(buf,"OK")!=0)
	{
	  if ( (read_ret = read( desc, buf, sizeof buf )) > 0 ) 
	    {
	      /* Recoit une requete = un message */
	      //      buf[read_ret]=(char)0;
	      printf("Ear=%d recoit de caller=%s,%d : %s\n",desc
		     , inet_ntoa(caller.sin_addr)
		     , ntohs(caller.sin_port)
		     , buf);
	      printf("ecris %d octetc\n",read_ret);
	      if (read_ret != 3) fwrite(buf,1,read_ret,fichier);
	    }
	  else
	    {
	      printf("FIN de connection sur desc=%d de caller=%s,%d\n",desc
		     , inet_ntoa(caller.sin_addr)
		     , ntohs(caller.sin_port)
		     ); 
	      fclose(fichier);
	      return(DECONNECTE);
	    };
	  
 	}
      
      fclose(fichier);
      write(desc,"REQUETE",8);      
      printf("fichier completement receptionne\n");
      if ( (read_ret = read( desc, buf, sizeof buf )) > 0 ) 
	{
	  /* Recoit une requete = un message */
	  //      buf[read_ret]=(char)0;
	  printf("Ear=%d recoit de caller=%s,%d : %s\n",desc
		 , inet_ntoa(caller.sin_addr)
		 , ntohs(caller.sin_port)
		 , buf);
	  printf("ecris %d octetc\n",read_ret);
	  sprintf(commande,"./console %s %s %s",nom_in,nom_out,buf);	      
	  printf("mode corectement receptionne : %s\n",buf);
	}
      else
	{
	  printf("FIN de connection sur desc=%d de caller=%s,%d\n",desc
		 , inet_ntoa(caller.sin_addr)
		 , ntohs(caller.sin_port)
		 ); 
	  
	  return(DECONNECTE);
	};
      
      

      printf("Lancement du calcul : %s\n",commande);
      system(commande);
      fichier = fopen(nom_out,"rb");
      read_ret = fread(buf,1,sizeof (buf),fichier);
      fclose (fichier);
      /* Renvoit une reponse = le message que l'on vient de recevoir */
      
      if ( (read_ret = send (desc,buf,read_ret,MSG_OOB)) > 0 )
	{
	  printf("octets sent : %d\n",read_ret);
	  write(desc,"FIN",4);
	}
      else
	{
	  char s[BUFSIZ];
	  sprintf(s,  "erreur ecriture socket"); perror(s);
	  return(KO); 
	};
    
  return(OK);
}

main( argc, argv )
int argc; char *argv[];
{
    int sock;				
    int ear;			
    pid_t	pid;
    struct sockaddr_in sockaddr;	
    int sockaddr_in_length = sizeof(struct sockaddr_in);
    int fromlen = sizeof(struct sockaddr_in);
    ftmp=0;
    /* evite les zombies */
    signal(SIGCHLD,SIG_IGN);
    signal(SIGPIPE, (sighandler_t)Rupture);
    signal(SIGINT, (sighandler_t)Kill);
    if ( (sock = socket( AF_INET, SOCK_STREAM, 0 )) < 0 ) {
	char s[BUFSIZ];
	sprintf( s, "%s: can't assign fd for socket", argv[0] );
	perror(s);
	exit(__LINE__);
    }

    sockaddr.sin_family = AF_INET;
    sockaddr.sin_addr.s_addr = INADDR_ANY;	
    sockaddr.sin_port = htons(2000);

    if ( bind( sock, (struct sockaddr *) &sockaddr, sizeof sockaddr ) < 0 ) {
	char s[BUFSIZ];
	sprintf( s, "%s: can't bind socket (%d)", argv[0], sock );
	perror(s);
	exit(__LINE__);
    }


    printf("opened socket as fd (%d) on port (%d) for stream i/o\n",
	    sock, ntohs(sockaddr.sin_port) );

    printf(
"struct sockaddr_in {\n\
    sin_family		= %d\n\
    sin_addr.s_addr	= %d\n\
    sin_port		= %d\n\
} sockaddr;\n"
, sockaddr.sin_family
, sockaddr.sin_addr.s_addr
, ntohs(sockaddr.sin_port)
    );

    if ( getsockname( sock, (struct sockaddr *) &sockaddr,
		      (int *)&sockaddr_in_length ) < 0 ) {
	char s[BUFSIZ];
	sprintf( s, "%s: can't get port number of socket (%d)",
		argv[0], sock );
	perror(s);
	exit(__LINE__);
    }

    printf("opened socket as fd (%d) on port (%d) for stream i/o\n",
	    sock, ntohs(sockaddr.sin_port) );

    printf(
"struct sockaddr_in {\n\
    sin_family		= %d\n\
    sin_addr.s_addr	= %d\n\
    sin_port		= %d\n\
} sockaddr;\n"
, sockaddr.sin_family
, sockaddr.sin_addr.s_addr
, ntohs(sockaddr.sin_port)
    );

    listen( sock, 2 );			

    while(1) {

           if ((ear=accept(sock,(struct sockaddr *)&caller, &fromlen )) < 0 ) 
           { perror(argv[0]); exit(__LINE__); }
	   ftmp = ftmp + 2;
    printf("ear=%d\n",ear);
    printf(
"struct sockaddr_in {\n\
    sin_family          = %d\n\
    sin_addr.s_addr     = %s\n\
    sin_port (!!!)      = %d\n\
} caller;\n"
, caller.sin_family
, inet_ntoa(caller.sin_addr)
/* , caller.sin_addr.s_addr -- gives an unsigned long, not a struct in_addr */
, ntohs(caller.sin_port)
    );
 
    if ((pid =fork()) < 0)
           { perror(argv[0]); exit(__LINE__); }
    if (pid==0)
    {
	/* Je suis le fils */
	/* Je ferme le descripteur d'attente des connections */
      close(sock);
	while (1)
	{
	   sleep(1);
	   switch (traiterRequete(ear)){
		case DECONNECTE:                                                         
		  exit(1);
                  break;                                                              
             	default:                                                                 
                  break;                                                              
           };                     
	}
	
    }
    else
    {
	/* Je suis le pere */
	close(ear);
    }

    }; /* while (1) */
}
