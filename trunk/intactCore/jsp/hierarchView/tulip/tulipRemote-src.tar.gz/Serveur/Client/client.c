/* isockt.c -- open an internet socket and talk into it */
/* (C) 1991 Blair P. Houghton, All Rights Reserved, copying and */
/* distribution permitted with copyright intact.		*/

#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <math.h>
#include <string.h>
#include <unistd.h>

typedef void (*sighandler_t)(int);

int Kill()
{
	printf("Signal kill \n");
	exit(3);
}

int Rupture()
{
	printf("Rupture connexion\n");
	exit(2);
}
int n_line = 6;

int main(argc,argv)
int argc; char *argv[];
{

    int plug;			
    FILE * fichier;
    struct sockaddr_in socketname;	
    struct hostent *remote_host;
    int read_ret;
    char buf[100000];

 
    signal(SIGINT,(sighandler_t)Kill);
    signal(SIGPIPE,(sighandler_t)Rupture);


    if ( (plug = socket( AF_INET, SOCK_STREAM, 0 )) < 0 )
	perror(argv[0]);

    socketname.sin_family = AF_INET;
    if ( (remote_host = gethostbyname( argv[1] )) == (struct hostent *)NULL ) {
	fprintf( stderr, "%s: unknown host: %s\n",
		 argv[0], argv[1] );
	exit(__LINE__);
    }
    (void) memcpy(  (char *) &socketname.sin_addr,(char *)remote_host->h_addr,
		  (size_t) remote_host->h_length );
    socketname.sin_port = htons(atoi(argv[2]));

    if ( connect( plug, (struct sockaddr *) &socketname,
		  sizeof socketname ) < 0 ) {
	perror(argv[0]);
	exit(__LINE__);
    }

    fichier = fopen(argv[3],"rb");
    read_ret = fread(buf,1,sizeof(buf),fichier);
    fclose(fichier);
	if ( send ( plug, buf, read_ret,MSG_OOB ) < 0 ) {
	    perror(argv[0]);
	    exit(__LINE__);
	}
        else
        {
	  
	  write(plug,"OK",3);
	  if ( (read_ret = read( plug, buf, sizeof buf)) > 0 )
	    {
	      if (strcmp(buf,"REQUETE") != 0) 
		{
		  printf("fin\n");
		  fclose (fichier);		      
		  exit(0);
		}	  
	    }  
	  if (argc == 6) write(plug,argv[5],strlen(argv[5])+1);
	  else write(plug,argv[4],strlen(argv[4]));
	  
	  if (argc == 6) fichier = fopen(argv[4],"wb");
	  else fichier = fopen(argv[3],"wb");
	  
       
	  while(1)
	    {
	      
	      if ( (read_ret = read( plug, buf, sizeof buf)) > 0 )
		{
		  if (strcmp(buf,"FIN") == 0) 
		    {
		      printf("fin\n");
		      fclose (fichier);		      
		      exit(0);
		    }
		
		  //printf( "%s: read from socket as follows:\n(%s)\n", argv[0], buf );
		  printf("octets recu : %d\n",read_ret);
		  
		  fwrite(buf,1,read_ret,fichier);
		 
		}
	    };
	
	};
    

    exit(0);
}







