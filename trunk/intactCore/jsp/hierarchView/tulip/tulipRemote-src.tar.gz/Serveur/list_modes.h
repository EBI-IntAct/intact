// This file contain the modes (propertyProxy with D.Auber words) of tulip that could be executed ( else than defaults modes)
// You use a mask to tell tulip which mode you want to see in your tulip file.

// for the section layout : viewLayout

#include <TlpTools.h>
#include <PropertyProxyContainer.h>
#include <fstream.h> 
#include <Color.h>


#define Circular 1
#define GEM 2
#define GeneralGraph 4
#define GeneralGraph3D 8
#define GeneralGraphBox 16
#define Random 32
#define SpringElectrical 64
#define Tute 128

//for the section Sizes : viewSize
	
#define Auto_sizing 256 
#define FitToLabel 512

//for the section metric : viewMetric
// Be careful -> this action action create a color proxy (necessary) with a linear default color proxy. If you want to change te color proxy then call for the modes colors : see below

#define ConnecandTree 1024
#define Barycenter 2048
#define Cluster 4096
#define DagLevel 8192

//for the section color : view color
#define Linear 16384
#define Distribution 32768

//as  you see can, clearly not all the modes are available. This was an approach for the tulip server, or more...for the tulip console that could be run with an RPC call and not with my server-client architecture (primitive).


class ConstructConsoleProxy
{   
  private :
    SuperGraph * myGraph;
    string errMsg;
    bool cached, result;
    int constructLayoutProxy(int mode);
    int constructViewSizeProxy(int mode);
    int constructviewMetricProxy(int mode);
    int constructviewColorProxy(int mode);
  
  public :

    ConstructConsoleProxy(int modes,SuperGraph * graphe);
    int deleteIntermediaire(int mode);
};




