 /**
  Author: David Auber, Vander Linden Hans
  Email : auber@labri.fr, vanderli@enserb.fr
  Last modification : 06/02/2002
  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.
 */

#include "list_modes.h"
#include <stdlib.h>
#include <stdio.h>

/**
    Little tutorial program which load a graph from a file arg[1] draw it
with GEM algorithm
    and ouput it on the standart ouput.
  */
 
 using namespace TlpTools;

// file://Number of elements of the graph.
 const unsigned int GSIZE=1000;

 int main(int argc, char* argv[]) {

   fstream ficOut ;

//   file://Create a new SuperGraph

   if (argc < 3 || argc > 4) {
     cerr << "Erreur " << endl;
     cerr << "Syntax : console file_in file_out [optionnel MASK]" << endl;
   }
   loadPlugins();
   SuperGraph* myGraph=importGraph(argv[1]);


   /************** appelle de la classe constructConsoleProxy**********/

   if (argc == 3 || strcmp("0",argv[3])==0)
     {
       cout << "traitement par default" << endl;
       ConstructConsoleProxy * console = new ConstructConsoleProxy(GEM|Auto_sizing|ConnecandTree,myGraph);
       console -> deleteIntermediaire(GEM|Auto_sizing|ConnecandTree);
       myGraph->getPropertyProxyContainer()->delLocalProxy(string("MetricProxy"));
     }
   else
     {
       cout << "traitement particulier" << endl;
       ConstructConsoleProxy * console = new ConstructConsoleProxy(atoi(argv[3]),myGraph);
       console -> deleteIntermediaire(atoi(argv[3]));
       myGraph->getPropertyProxyContainer()->delLocalProxy(string("MetricProxy"));
     }


   /******************* sauvegarde dans un fichier***************************/
   ficOut.open(argv[2],ios::out);   
   exportGraph(myGraph,ficOut);
   ficOut.close();
   exit(0);
 }
 
