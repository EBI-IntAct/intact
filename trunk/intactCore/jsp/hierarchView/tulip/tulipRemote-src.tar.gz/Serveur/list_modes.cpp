#include "list_modes.h"

ConstructConsoleProxy::ConstructConsoleProxy(int modes, SuperGraph * graph)
{

  myGraph = graph;
  int mode_courant = modes;
  cout << "creation de la console" << endl;

  /* Traitement des requetes view Layout */

  if ((mode_courant & Tute)== Tute) constructLayoutProxy(Tute);
  if ((mode_courant & SpringElectrical)== SpringElectrical) constructLayoutProxy(SpringElectrical);
  if ((mode_courant & Random)== Random) constructLayoutProxy(Random);
  if ((mode_courant & GeneralGraphBox)== GeneralGraphBox) constructLayoutProxy(GeneralGraphBox);
  if ((mode_courant & GeneralGraph3D)== GeneralGraph3D) constructLayoutProxy(GeneralGraph3D);
  if ((mode_courant & GeneralGraph)== GeneralGraph) constructLayoutProxy(GeneralGraph);
  if ((mode_courant & GEM)== GEM) constructLayoutProxy(GEM);
  if ((mode_courant & Circular)== Circular) constructLayoutProxy(Circular);

/* Traitement des requetes view Size */

  if ((mode_courant & FitToLabel)== FitToLabel) constructViewSizeProxy(FitToLabel);
  if ((mode_courant & Auto_sizing)== Auto_sizing) constructViewSizeProxy(Auto_sizing);;

  /* traitement des requetes view Metric */

  if ((mode_courant & DagLevel)== DagLevel) constructviewMetricProxy(DagLevel);
  if ((mode_courant & Cluster)== Cluster) constructviewMetricProxy(Cluster);
  if ((mode_courant & Barycenter)== Barycenter) constructviewMetricProxy(Barycenter);;
  if ((mode_courant & ConnecandTree)== ConnecandTree) constructviewMetricProxy(ConnecandTree);

    /* TRaitement des requetes view Color */
  if ((mode_courant & Linear)== Linear) constructViewSizeProxy(Linear);
  if ((mode_courant & Distribution)== Distribution) constructViewSizeProxy(Distribution);;

}

int ConstructConsoleProxy::constructLayoutProxy(int mode)
{
  string mod_str;
  cout << "depart de la creation de la section layout" << endl;
  switch(mode)
    {
    case Circular : mod_str = string("Circular");break;
    case GEM : mod_str = string("GEM");break;
    case GeneralGraph : mod_str = string("GeneralGraph");break;
    case GeneralGraph3D : mod_str = string("GeneralGraph3D");break;
    case GeneralGraphBox : mod_str = string("GeneralGraphBox");break;
    case Random : mod_str = string("Random");break;
    case SpringElectrical : mod_str = string("SpringElectrical");break;
    case Tute : mod_str = string("Tute");break;
    }
  cout << "mode choisi : " << mod_str << endl;
       LayoutProxy * myLayout=getProxy<LayoutProxy>(myGraph,mod_str,cached,result,errMsg);


       if (cached) result=myLayout->recompute(errMsg);
       if (!result) 
	 {
	   cout << "Tulip Algorithm Check Failed::" << errMsg << endl;
	   return (-1);
	 }
       *getProxy<LayoutProxy>(myGraph,"viewLayout")=*myLayout;

       return 0;
}

int ConstructConsoleProxy::constructViewSizeProxy(int mode)
{
  
  string mod_str;
  cout << "depart de la creation de la section Size" << endl;
  switch(mode)
    {
    case Auto_sizing : mod_str = string("Auto_sizing");break;
    case FitToLabel : mod_str = string("FitToLabel");break;
    }
  cout << "mode choisi : " << mod_str << endl;
       SizesProxy * mySize=getProxy<SizesProxy>(myGraph,mod_str,cached,result,errMsg);


       if (cached) result=mySize->recompute(errMsg);
       if (!result) 
	 {
	   cout << "Tulip Algorithm Check Failed::" << errMsg << endl;
	   return (-1);
	 }
       *getProxy<SizesProxy>(myGraph,"viewSize")=*mySize;

       return 0;
}

int ConstructConsoleProxy::constructviewMetricProxy(int mode)
{
  cout << "depart de la creation de la section Metric" << endl;
 string mod_str;
  switch(mode)
    {
    case ConnecandTree : mod_str = string("Connected & Tree Component");break;
    case Barycenter : mod_str = string("Barycenter");break;
    case Cluster : mod_str = string("Cluster");break;    
    case DagLevel : mod_str = string("DagLevel");break;
    }
  cout << "mode choisi : " << mod_str << endl;
  
  MetricProxy *myMetric=getLocalProxy<MetricProxy>(myGraph,mod_str,cached,result,errMsg);
  if (cached) result=myMetric->recompute(errMsg);
       if (!result) 
	 {
	   cout << "Tulip Algorithm Check Failed::" << errMsg << endl;
	   return (-1);
	 }
       
       *getLocalProxy<MetricProxy>(myGraph,"viewMetric")=*myMetric;
       
       ColorsProxy *myColorMap=getLocalProxy<ColorsProxy>(myGraph,"Linear",cached,result,errMsg);
       if (cached) result=myColorMap->recompute(errMsg);
       if (!result)	 
       	 {
	   cout << "Tulip Algorithm Check Failed::" << errMsg << endl;
	   return (-1);
	 }

       getProxy<ColorsProxy>(myGraph,"viewColors")->setAllNodeValue(*(new Color(255,0,0)));
       getProxy<ColorsProxy>(myGraph,"viewColors")->setAllEdgeValue(*(new Color(0,85,255)));
       *getProxy<ColorsProxy>(myGraph,"viewColors")=*myColorMap;
       return 0; 
}

int ConstructConsoleProxy::constructviewColorProxy(int mode)
{

  string mod_str;
  cout << "depart de la creation de la section Size" << endl;
  switch(mode)
    {
    case Linear : mod_str = string("Linear");break;
    case Distribution : mod_str = string("Distribution");break;
    }
  cout << "mode choisi : " << mod_str << endl;
       ColorsProxy * myColor=getProxy<ColorsProxy>(myGraph,mod_str,cached,result,errMsg);


       if (cached) result=myColor->recompute(errMsg);
       if (!result) 
	 {
	   cout << "Tulip Algorithm Check Failed::" << errMsg << endl;
	   return (-1);
	 }
       *getProxy<ColorsProxy>(myGraph,"viewColors")=*myColor;
       
       return 0;
}

int ConstructConsoleProxy::deleteIntermediaire(int mode)
{
  int mode_courant = mode;
  if ((mode_courant & Tute)== Tute) 
    myGraph->getPropertyProxyContainer()->delLocalProxy(string("Tute"));
  if ((mode_courant & SpringElectrical)== SpringElectrical) 
    myGraph->getPropertyProxyContainer()->delLocalProxy(string("SpringElectrical"));
  if ((mode_courant & Random)== Random) 
    myGraph->getPropertyProxyContainer()->delLocalProxy(string("Random"));
  if ((mode_courant & GeneralGraphBox)== GeneralGraphBox) 
    myGraph->getPropertyProxyContainer()->delLocalProxy(string("GeneralGraphBox"));
  if ((mode_courant & GeneralGraph3D)== GeneralGraph3D) 
    myGraph->getPropertyProxyContainer()->delLocalProxy(string("GeneralGraph3D"));
  if ((mode_courant & GeneralGraph)== GeneralGraph) 
    myGraph->getPropertyProxyContainer()->delLocalProxy(string("GeneralGraph"));
  if ((mode_courant & GEM)== GEM) 
    myGraph->getPropertyProxyContainer()->delLocalProxy(string("GEM"));
  if ((mode_courant & Circular)== Circular) 
    myGraph->getPropertyProxyContainer()->delLocalProxy(string("Circular"));

  /* traitement des requetes view Metric */

  if ((mode_courant & DagLevel)== DagLevel) 
    {
      myGraph->getPropertyProxyContainer()->delLocalProxy(string("DagLevel"));
      deleteIntermediaire(Linear);
    }
  if ((mode_courant & Cluster)== Cluster)
    {
      myGraph->getPropertyProxyContainer()->delLocalProxy(string("Cluster"));
      deleteIntermediaire(Linear);
    }
  if ((mode_courant & Barycenter)== Barycenter)
    {
      myGraph->getPropertyProxyContainer()->delLocalProxy(string("Barycenter"));      deleteIntermediaire(Linear);
    }
  if ((mode_courant & ConnecandTree)== ConnecandTree)
    {
      myGraph->getPropertyProxyContainer()->delLocalProxy(string("Connected & Tree Component"));
      deleteIntermediaire(Linear);
    }

  /* Traitement des requetes view Size */

  if ((mode_courant & FitToLabel)== FitToLabel) 
    myGraph->getPropertyProxyContainer()->delLocalProxy(string("FitToLabel"));
  if ((mode_courant & Auto_sizing)== Auto_sizing) 
    myGraph->getPropertyProxyContainer()->delLocalProxy(string("Auto_sizing"));

  /* TRaitement des requetes view Color */
  if ((mode_courant & Linear)== Linear) 
    myGraph->getPropertyProxyContainer()->delLocalProxy(string("Linear"));
  if ((mode_courant & Distribution)== Distribution) 
    myGraph->getPropertyProxyContainer()->delLocalProxy(string("Distribution"));
  return 0;
}
